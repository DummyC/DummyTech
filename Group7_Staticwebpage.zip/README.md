# Dummy Technologies

this is just a static company portfolio webpage